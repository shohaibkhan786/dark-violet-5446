function showSection(id) {
  document.querySelectorAll("section").forEach(sec => sec.style.display = "none");
  document.getElementById(id).style.display = "block";
}
document.getElementById("menuBtn").addEventListener("click", () => {
  document.getElementById("menuItems").classList.toggle("hidden");
});
firebase.auth().onAuthStateChanged(user => {
  if (user && user.email === "vidorasiteoffcial@gmail.com") {
    document.querySelector(".admin-only").style.display = "inline";
  }
});